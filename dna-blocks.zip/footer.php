            <!--<footer class="site-footer">
             <?php

                  $args = array(
                      'theme_location' => 'footer'
                 );

                    ?>

                <p>Danielle Aubry - &copy; <?php echo date('Y'); ?></p>

            </footer>-->

        </div><!-- main inner flex-container -->

    <?php wp_footer(); ?>

        <!-- mobile navigation menu -->
        <div class="mobile-nav">
                <div>
                    <span id="sort-icon"><span class="sort-mobile dashicons dashicons-sort"></span>sort</span>
                </div>
                <div>
                    <span id="menu-icon" class="menu-icon--is-visible menu-icon"><span class="dashicons dashicons-menu"></span>menu</span>
                    <span id="close-icon" class="close-icon"><span class="dashicons dashicons-no-alt"></span>close</span>
                </div>
                <div>
                    <span id="search-icon"><span class="search-mobile dashicons dashicons-search"></span>search</span>
                </div>
        </div>
    </div><!-- mobile navigation menu -->
</body>
</html>